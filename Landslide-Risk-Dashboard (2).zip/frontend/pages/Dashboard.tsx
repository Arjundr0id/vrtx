import { useEffect, useMemo, useState } from 'react'
import {
  Activity,
  AlertTriangle,
  BellRing,
  Bot,
  ChevronRight,
  CloudRain,
  Compass,
  Cpu,
  History,
  Info,
  Leaf,
  MapPin,
  Mountain,
  Navigation,
  Play,
  Route,
  Search,
  ShieldAlert,
  Sparkles,
  Trees,
  Waves,
} from 'lucide-react'
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts'
import { Button } from '../lib/shadcn/button'
import { Input } from '../lib/shadcn/input'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../lib/shadcn/select'
import { Tabs, TabsList, TabsTrigger } from '../lib/shadcn/tabs'
import { buildEvacuationRoute, emergencyDataFor, type EvacuationRoute } from './data/emergencyData'
import SummaryBanner from './ui/SummaryBanner'
import EmergencyHub from './ui/EmergencyHub'
import ResponsePlanner from './ui/ResponsePlanner'
import RiskMap from './ui/RiskMap'
import EvacuationRouteCard from './ui/EvacuationRouteCard'
import PopulationRisk from './ui/PopulationRisk'
import WeatherConditions from './ui/WeatherConditions'
import RoadStatusList from './ui/RoadStatus'

type RiskLevel = 'LOW' | 'MODERATE' | 'HIGH' | 'EXTREME'
type LocationData = {
  name: string
  state: string
  risk: number
  rainfall: number
  moisture: number
  slope: number
  elevation: string
  cover: string
  terrain: string
  coords: { x: string; y: string }
}

const locations: LocationData[] = [
  { name: 'Guwahati', state: 'Assam', risk: 47, rainfall: 78, moisture: 52, slope: 24, elevation: '55 m', cover: 'Urban / Vegetation', terrain: 'Moderate instability', coords: { x: '30%', y: '62%' } },
  { name: 'Shillong', state: 'Meghalaya', risk: 78, rainfall: 142, moisture: 68, slope: 32, elevation: '1,496 m', cover: 'Forest / Vegetation', terrain: 'Elevated instability', coords: { x: '36%', y: '66%' } },
  { name: 'Gangtok', state: 'Sikkim', risk: 91, rainfall: 210, moisture: 86, slope: 38, elevation: '1,650 m', cover: 'Dense forest', terrain: 'Severe instability', coords: { x: '18%', y: '29%' } },
  { name: 'Imphal', state: 'Manipur', risk: 62, rainfall: 104, moisture: 59, slope: 28, elevation: '786 m', cover: 'Mixed vegetation', terrain: 'Moderate instability', coords: { x: '56%', y: '78%' } },
  { name: 'Aizawl', state: 'Mizoram', risk: 83, rainfall: 168, moisture: 74, slope: 35, elevation: '1,132 m', cover: 'Forest / Vegetation', terrain: 'Elevated instability', coords: { x: '61%', y: '89%' } },
  { name: 'Kohima', state: 'Nagaland', risk: 53, rainfall: 85, moisture: 54, slope: 26, elevation: '1,261 m', cover: 'Mixed forest', terrain: 'Moderate instability', coords: { x: '71%', y: '59%' } },
  { name: 'Itanagar', state: 'Arunachal Pradesh', risk: 35, rainfall: 52, moisture: 43, slope: 20, elevation: '440 m', cover: 'Forest / Vegetation', terrain: 'Stable', coords: { x: '78%', y: '35%' } },
  { name: 'Agartala', state: 'Tripura', risk: 18, rainfall: 28, moisture: 31, slope: 12, elevation: '12 m', cover: 'Lowland vegetation', terrain: 'Stable', coords: { x: '22%', y: '87%' } },
]

const trendData = [
  { day: 'Mon', rainfall: 48, moisture: 42, risk: 29 },
  { day: 'Tue', rainfall: 62, moisture: 48, risk: 38 },
  { day: 'Wed', rainfall: 74, moisture: 54, risk: 49 },
  { day: 'Thu', rainfall: 96, moisture: 59, risk: 61 },
  { day: 'Fri', rainfall: 123, moisture: 64, risk: 69 },
  { day: 'Sat', rainfall: 142, moisture: 68, risk: 78 },
  { day: 'Today', rainfall: 136, moisture: 67, risk: 76 },
]

function getRiskLevel(risk: number): RiskLevel {
  if (risk >= 86) return 'EXTREME'
  if (risk >= 65) return 'HIGH'
  if (risk >= 40) return 'MODERATE'
  return 'LOW'
}

function riskTone(level: RiskLevel) {
  return {
    LOW: { text: 'text-emerald-400', bg: 'bg-emerald-400', soft: 'bg-emerald-400/10 border-emerald-400/25', label: 'Low exposure' },
    MODERATE: { text: 'text-yellow-300', bg: 'bg-yellow-300', soft: 'bg-yellow-300/10 border-yellow-300/25', label: 'Elevated monitoring' },
    HIGH: { text: 'text-orange-400', bg: 'bg-orange-400', soft: 'bg-orange-400/10 border-orange-400/25', label: 'Early warning active' },
    EXTREME: { text: 'text-red-400', bg: 'bg-red-400', soft: 'bg-red-400/10 border-red-400/25', label: 'Critical attention' },
  }[level]
}

function SectionTitle({ eyebrow, title, action }: { eyebrow?: string; title: string; action?: string }) {
  return <div className="flex items-end justify-between gap-4"><div>{eyebrow && <p className="mb-1 text-[10px] font-bold uppercase tracking-[0.2em] text-primary">{eyebrow}</p>}<h2 className="text-xl font-semibold tracking-tight text-foreground">{title}</h2></div>{action && <button className="group flex items-center gap-1 text-xs text-muted-foreground transition hover:text-foreground">{action}<ChevronRight className="h-3.5 w-3.5 transition group-hover:translate-x-0.5" /></button>}</div>
}

function MetricCard({ icon: Icon, label, value, sub, tone }: { icon: typeof CloudRain; label: string; value: string; sub: string; tone?: string | undefined }) {
  return <div className="rounded-2xl border border-border bg-card/85 p-4 shadow-retool-sm backdrop-blur transition duration-300 hover:-translate-y-0.5 hover:border-primary/40"><div className="mb-4 flex items-start justify-between"><div className="rounded-xl bg-secondary p-2.5"><Icon className={`h-4 w-4 ${tone ?? 'text-primary'}`} /></div><span className="h-1.5 w-1.5 rounded-full bg-primary shadow-[0_0_10px_hsl(var(--primary))]" /></div><p className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">{label}</p><p className="mt-1 text-2xl font-semibold tracking-tight text-foreground">{value}</p><p className="mt-1 text-xs text-muted-foreground">{sub}</p></div>
}

const navItems = ['Dashboard', 'Emergency', 'Risk Map', 'Safer Routes', 'Alerts', 'About'] as const
type NavItem = typeof navItems[number]

export default function Dashboard() {
  const [selectedName, setSelectedName] = useState('Shillong')
  const [tab, setTab] = useState<NavItem>('Dashboard')
  const [showWhy, setShowWhy] = useState(false)
  const [trend, setTrend] = useState<'rainfall' | 'moisture' | 'risk'>('rainfall')
  const [demo, setDemo] = useState(false)
  const [routeStart, setRouteStart] = useState('Shillong')
  const [routeEnd, setRouteEnd] = useState('Aizawl')
  const [routeCalculated, setRouteCalculated] = useState(true)
  const [evacRoute, setEvacRoute] = useState<EvacuationRoute | null>(null)
  const selected = useMemo(() => locations.find((location) => location.name === selectedName) ?? locations[1] ?? locations[0]!, [selectedName])
  const level = getRiskLevel(selected.risk)
  const tone = riskTone(level)
  const emergency = useMemo(() => emergencyDataFor(selected), [selected])
  const criticalRisk = level === 'HIGH' || level === 'EXTREME'
  const generateEvacuationRoute = () => setEvacRoute(buildEvacuationRoute(selected, emergency))
  const routeOrigin = locations.find((location) => location.name === routeStart) ?? locations[0]!
  const routeDestination = locations.find((location) => location.name === routeEnd) ?? locations[1]!
  const routeBaseDistance = Math.max(42, Math.round(Math.abs(routeOrigin.risk - routeDestination.risk) * 0.55 + 48))
  const routeExposure = Math.round((routeOrigin.risk + routeDestination.risk) / 2)
  const routeExposureLevel = getRiskLevel(routeExposure)
  const routeTone = riskTone(routeExposureLevel)

  useEffect(() => {
    if (!demo) return
    const sequence = ['Agartala', 'Guwahati', 'Shillong', 'Gangtok']
    let index = 0
    const timer = window.setInterval(() => { index = (index + 1) % sequence.length; const next = sequence[index]; if (next) setSelectedName(next) }, 2200)
    return () => window.clearInterval(timer)
  }, [demo])

  const scrollTo = (id: string) => document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' })
  const headline = level === 'LOW' ? 'Conditions are presently stable' : level === 'MODERATE' ? 'Monitor local conditions closely' : 'Heavy rainfall is raising instability'

  // Explainable-AI factor weights (demo weighting, not scientifically validated)
  const contributions = [
    { icon: CloudRain, name: 'Rainfall', value: Math.min(94, selected.rainfall / 2), impact: 'High impact' },
    { icon: Mountain, name: 'Slope', value: Math.min(84, selected.slope * 2.1), impact: 'Medium-high impact' },
    { icon: Waves, name: 'Soil moisture', value: selected.moisture, impact: 'High impact' },
    { icon: ShieldAlert, name: 'Soil stability', value: Math.min(88, 100 - selected.moisture), impact: 'Medium impact' },
    { icon: History, name: 'Historical landslide activity', value: Math.min(80, 30 + selected.risk / 3), impact: 'Medium impact' },
    { icon: Route, name: 'Infrastructure / road exposure', value: selected.cover.includes('Urban') ? 62 : 38, impact: 'Low-medium impact' },
  ]
  const aiExplanation = level === 'LOW'
    ? 'Light recent rainfall, gentler terrain and lower soil moisture keep the estimated probability of slope failure low in this demo estimate.'
    : `${selected.rainfall >= 100 ? 'High rainfall' : 'Recent rainfall'} combined with ${selected.slope >= 30 ? 'steep terrain' : 'moderate terrain'} and ${selected.moisture >= 60 ? 'elevated' : 'moderate'} soil moisture is ${level === 'EXTREME' ? 'strongly increasing' : 'increasing'} the probability of slope failure.`

  return <main className="min-h-screen overflow-x-hidden bg-background text-foreground"><div className="pointer-events-none fixed inset-0 -z-10 overflow-hidden"><div className="absolute -left-24 -top-24 h-96 w-96 rounded-full bg-primary/10 blur-[120px]" /><div className="absolute right-0 top-72 h-80 w-80 rounded-full bg-blue-500/10 blur-[120px]" /><div className="absolute inset-0 opacity-[0.035] [background-image:linear-gradient(hsl(var(--foreground))_1px,transparent_1px),linear-gradient(90deg,hsl(var(--foreground))_1px,transparent_1px)] [background-size:48px_48px]" /></div>
    <header className="sticky top-0 z-30 border-b border-border/80 bg-background/85 backdrop-blur-xl"><div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6"><button className="flex items-center gap-2.5" onClick={() => scrollTo('dashboard')}><div className="grid h-9 w-9 place-items-center rounded-xl bg-primary text-primary-foreground shadow-[0_0_25px_hsl(var(--primary)/0.25)]"><Mountain className="h-5 w-5" /></div><div className="text-left"><p className="text-sm font-bold tracking-tight">LandslideGuard <span className="text-primary">AI</span></p><p className="text-[9px] uppercase tracking-[0.15em] text-muted-foreground">NER monitoring network</p></div></button><nav className="hidden items-center gap-1 lg:flex">{navItems.map((item) => <button key={item} onClick={() => { setTab(item); scrollTo(item === 'Dashboard' ? 'dashboard' : item === 'Emergency' ? 'emergency' : item === 'Risk Map' ? 'risk-map' : item === 'Safer Routes' ? 'routes' : item === 'Alerts' ? 'alerts' : 'about') }} className={`rounded-lg px-3 py-2 text-xs font-medium transition ${tab === item ? 'bg-secondary text-foreground' : 'text-muted-foreground hover:text-foreground'}`}>{item}</button>)}</nav><div className="flex items-center gap-2"><Button variant="outline" onClick={() => setDemo(!demo)} className={`hidden h-9 gap-2 rounded-xl border-border text-xs sm:flex ${demo ? 'border-primary/50 bg-primary/10 text-primary' : ''}`}><Play className="h-3.5 w-3.5" />{demo ? 'Demo running' : 'Demo Mode'}</Button><Button onClick={() => scrollTo('risk')} className="h-9 gap-2 rounded-xl text-xs font-bold"><Activity className="h-3.5 w-3.5" />Check Risk</Button></div></div></header>

    <section id="dashboard" className="mx-auto max-w-7xl px-4 pb-10 pt-9 sm:px-6 lg:pt-14"><div className="grid gap-7 lg:grid-cols-[1fr_auto]"><div><div className="mb-4 inline-flex items-center gap-2 rounded-full border border-primary/25 bg-primary/10 px-3 py-1.5 text-[10px] font-bold uppercase tracking-[0.14em] text-primary"><span className="h-1.5 w-1.5 animate-pulse rounded-full bg-primary" />AI-powered early warning indicator</div><h1 className="max-w-2xl text-3xl font-semibold leading-tight tracking-tight sm:text-5xl">Predict risk. <span className="text-primary">Warn early.</span> Travel safer.</h1><p className="mt-4 max-w-xl text-sm leading-6 text-muted-foreground">Prototype decision support for terrain-aware landslide risk monitoring across India’s North Eastern Region — now spanning the full <span className="font-medium text-foreground">DETECT → PREDICT → ASSESS → ALERT → EVACUATE → RESPOND</span> workflow.</p></div><div className="flex items-end"><div className="rounded-2xl border border-border bg-card/75 p-1.5 shadow-retool-sm"><p className="px-3 pt-2 text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Regional status</p><div className="mt-1 flex items-center gap-3 rounded-xl bg-secondary/70 px-3 py-2"><span className="h-2 w-2 animate-pulse rounded-full bg-primary" /><span className="text-xs font-medium">8 locations online</span></div></div></div></div>
      <div className="mt-9 grid gap-3 rounded-2xl border border-border bg-card/60 p-3 shadow-retool-md backdrop-blur lg:grid-cols-[1fr_190px_auto]"><div className="relative"><Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" /><Input aria-label="Search location" placeholder="Search a city or district" className="h-11 border-0 bg-secondary/70 pl-10 text-sm shadow-none focus-visible:ring-1" /></div><Select value={selectedName} onValueChange={setSelectedName}><SelectTrigger className="h-11 border-0 bg-secondary/70 text-sm"><div className="flex items-center gap-2"><MapPin className="h-4 w-4 text-primary" /><SelectValue /></div></SelectTrigger><SelectContent>{locations.map((location) => <SelectItem key={location.name} value={location.name}>{location.name}, {location.state}</SelectItem>)}</SelectContent></Select><Button onClick={() => scrollTo('risk')} className="h-11 rounded-xl px-5 text-xs font-bold">Assess this location <ChevronRight className="ml-1 h-4 w-4" /></Button></div>
      <div className="mt-6"><SummaryBanner location={selected} data={emergency} routeAvailable={evacRoute !== null} /></div></section>

    <section id="emergency" className="mx-auto max-w-7xl space-y-5 px-4 pb-12 sm:px-6">
      {criticalRisk ? (
        <>
          <EmergencyHub location={selected} data={emergency} level={level} />
          <ResponsePlanner location={selected} data={emergency} level={level} />
        </>
      ) : (
        <div className="flex items-center gap-3 rounded-3xl border border-emerald-400/25 bg-emerald-400/[0.05] p-5 text-sm text-muted-foreground"><ShieldAlert className="h-5 w-5 shrink-0 text-emerald-400" />No emergency activation is indicated for {selected.name} at the current {level} risk level. The Emergency Response Hub, AI response plan and alert generator activate automatically when predicted risk becomes High or Extreme.</div>
      )}
    </section>

    <section id="risk" className="mx-auto max-w-7xl px-4 pb-8 sm:px-6"><div className="grid gap-5 lg:grid-cols-[1.1fr_0.9fr]"><div className="relative overflow-hidden rounded-3xl border border-border bg-card p-6 shadow-retool-md sm:p-8"><div className="absolute right-0 top-0 h-40 w-40 rounded-full bg-primary/10 blur-3xl" /><div className="relative flex flex-col gap-6 sm:flex-row sm:items-center"><div className="relative grid h-40 w-40 shrink-0 place-items-center rounded-full" style={{ background: `conic-gradient(${level === 'LOW' ? '#34d399' : level === 'MODERATE' ? '#facc15' : level === 'HIGH' ? '#fb923c' : '#f87171'} ${selected.risk * 3.6}deg, hsl(var(--secondary)) 0deg)` }}><div className="grid h-[126px] w-[126px] place-items-center rounded-full bg-card text-center"><p className={`text-4xl font-semibold tracking-tight ${tone.text}`}>{selected.risk}<span className="text-lg">%</span></p><p className="mt-1 text-[9px] font-bold uppercase tracking-[0.16em] text-muted-foreground">risk probability</p></div></div><div className="flex-1"><p className="text-[11px] font-bold uppercase tracking-[0.18em] text-muted-foreground">Estimated landslide risk</p><div className="mt-2 flex flex-wrap items-center gap-3"><h2 className={`text-4xl font-semibold tracking-tight ${tone.text}`}>{level}</h2><span className={`rounded-full border px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider ${tone.soft} ${tone.text}`}>{tone.label}</span></div><p className="mt-3 text-sm leading-6 text-muted-foreground">{headline} around <span className="font-medium text-foreground">{selected.name}</span>. This prototype combines environmental and terrain indicators.</p><Button variant="outline" onClick={() => setShowWhy(!showWhy)} className="mt-5 h-9 rounded-xl border-border text-xs">{showWhy ? 'Hide explanation' : 'Why is the risk high?'} <Info className="ml-2 h-3.5 w-3.5" /></Button></div></div>{showWhy && <div className="relative mt-6 rounded-2xl border border-primary/20 bg-primary/5 p-4 text-sm leading-6 text-muted-foreground"><Sparkles className="mr-2 inline h-4 w-4 text-primary" /> {aiExplanation}</div>}</div>
        <div className={`rounded-3xl border p-6 shadow-retool-md ${tone.soft} bg-card/40`}><div className="flex items-center justify-between"><div className="grid h-11 w-11 place-items-center rounded-2xl bg-background/50"><ShieldAlert className={`h-5 w-5 ${tone.text}`} /></div><span className={`text-[10px] font-bold uppercase tracking-wider ${tone.text}`}>Live demo signal</span></div><p className="mt-6 text-[11px] font-bold uppercase tracking-[0.16em] text-muted-foreground">Early warning status</p><h3 className="mt-2 text-2xl font-semibold">{level === 'LOW' ? 'No active warning' : `Landslide ${level === 'EXTREME' ? 'critical' : 'warning'}`}</h3><p className="mt-3 max-w-md text-sm leading-6 text-muted-foreground">{level === 'LOW' ? 'Continue routine monitoring. No elevated route avoidance is indicated by this demonstration data.' : 'Review local advisories, avoid identified high-risk roads, and consider the suggested safer route.'}</p><div className="mt-6 flex items-center gap-2 border-t border-border/60 pt-4 text-xs text-muted-foreground"><BellRing className={`h-4 w-4 ${tone.text}`} /> Notification panel ready for field teams</div></div></div></section>

    <section className="mx-auto max-w-7xl px-4 pb-12 sm:px-6"><div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-6"><MetricCard icon={CloudRain} label="Rainfall" value={`${selected.rainfall} mm`} sub="Last 24 hours" tone={selected.rainfall >= 100 ? tone.text : ''} /><MetricCard icon={Waves} label="Soil moisture" value={`${selected.moisture}%`} sub="Near-surface estimate" tone={selected.moisture >= 60 ? tone.text : ''} /><MetricCard icon={Mountain} label="Slope" value={`${selected.slope}°`} sub="Mean terrain gradient" tone={selected.slope >= 30 ? tone.text : ''} /><MetricCard icon={Compass} label="Elevation" value={selected.elevation} sub="Terrain model" /><MetricCard icon={Trees} label="Land cover" value={(selected.cover.includes(' / ') ? 'Forest' : selected.cover) ?? 'Unknown'} sub="Satellite classification" /><MetricCard icon={Activity} label="Terrain" value={selected.terrain.split(' ')[0] ?? 'Stable'} sub={selected.terrain} tone={tone.text} /></div></section>

    <section className="mx-auto grid max-w-7xl gap-5 px-4 pb-12 sm:px-6 lg:grid-cols-[0.9fr_1.1fr]"><div className="rounded-3xl border border-border bg-card p-6 shadow-retool-sm"><SectionTitle eyebrow="Explainable AI" title="Why this risk?" /><p className="mt-2 text-xs leading-5 text-muted-foreground">Relative feature contributions for this prototype prediction — demo weighting, not scientifically validated causes of a landslide.</p><div className="mt-7 space-y-4">{contributions.map((item) => <div key={item.name}><div className="mb-2 flex items-center justify-between text-xs"><span className="flex items-center gap-2 font-medium"><item.icon className="h-3.5 w-3.5 text-primary" />{item.name}</span><span className="flex items-center gap-2"><span className={`font-semibold ${tone.text}`}>{Math.round(item.value)}%</span><span className="text-muted-foreground">{item.impact}</span></span></div><div className="h-2 overflow-hidden rounded-full bg-secondary"><div className={`h-2 rounded-full ${tone.bg} transition-all duration-700`} style={{ width: `${item.value}%` }} /></div></div>)}</div><div className="mt-7 flex gap-2 rounded-xl border border-primary/20 bg-primary/5 p-3 text-xs leading-5 text-muted-foreground"><Sparkles className="mt-0.5 h-4 w-4 shrink-0 text-primary" /><span><span className="font-medium text-foreground">AI explanation:</span> {aiExplanation} Contribution percentages are relative demo weights, not validated model outputs.</span></div><div className="mt-3 flex gap-2 rounded-xl border border-border bg-secondary/40 p-3 text-[11px] leading-5 text-muted-foreground"><Info className="mt-0.5 h-4 w-4 shrink-0 text-primary" />The risk estimate is an early-warning indicator based on environmental and terrain data. It is a decision-support prototype, not a guaranteed prediction.</div></div>
      <RiskMap locations={locations} selectedName={selected.name} onSelect={setSelectedName} route={evacRoute} emergency={emergency} /></section>

    <section id="routes" className="mx-auto max-w-7xl px-4 pb-12 sm:px-6"><div className="rounded-3xl border border-border bg-card p-6 shadow-retool-sm sm:p-8"><div className="grid gap-7 lg:grid-cols-[1fr_1.5fr]"><div><SectionTitle eyebrow="Travel decision support" title="Safer route recommendation" /><p className="mt-2 text-sm leading-6 text-muted-foreground">Compare route exposure to estimated risk zones before travelling.</p><div className="mt-6 grid gap-3 sm:grid-cols-2"><div className="rounded-xl border border-border bg-secondary/45 p-3"><p className="mb-2 text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Starting location</p><Select value={routeStart} onValueChange={(value) => { setRouteStart(value); setRouteCalculated(false) }}><SelectTrigger className="h-9 border-0 bg-background text-xs"><SelectValue /></SelectTrigger><SelectContent>{locations.map((location) => <SelectItem key={`start-${location.name}`} value={location.name}>{location.name}, {location.state}</SelectItem>)}</SelectContent></Select></div><div className="rounded-xl border border-border bg-secondary/45 p-3"><p className="mb-2 text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Destination</p><Select value={routeEnd} onValueChange={(value) => { setRouteEnd(value); setRouteCalculated(false) }}><SelectTrigger className="h-9 border-0 bg-background text-xs"><SelectValue /></SelectTrigger><SelectContent>{locations.filter((location) => location.name !== routeStart).map((location) => <SelectItem key={`end-${location.name}`} value={location.name}>{location.name}, {location.state}</SelectItem>)}</SelectContent></Select></div></div><Button onClick={() => setRouteCalculated(true)} disabled={routeStart === routeEnd} className="mt-5 h-10 rounded-xl text-xs font-bold">Find safer route <Navigation className="ml-2 h-4 w-4" /></Button>{!routeCalculated && <p className="mt-3 text-xs text-muted-foreground">Choose your endpoints, then calculate route exposure.</p>}</div><div className="grid gap-3 sm:grid-cols-2">{routeCalculated ? <><div className={`rounded-2xl border p-5 ${routeTone.soft}`}><div className="flex items-center justify-between"><Route className={`h-5 w-5 ${routeTone.text}`} /><span className={`text-[10px] font-bold uppercase tracking-wider ${routeTone.text}`}>{routeExposureLevel} exposure</span></div><p className="mt-5 text-lg font-semibold">Shortest route</p><p className="mt-1 text-sm text-muted-foreground">{routeBaseDistance} km · {Math.max(1, Math.round(routeBaseDistance / 31))} hr {Math.round((routeBaseDistance % 31) * 1.8)} min</p><div className="mt-5 h-1.5 overflow-hidden rounded-full bg-secondary"><div className={`h-full rounded-full ${routeTone.bg}`} style={{ width: `${routeExposure}%` }} /></div><p className="mt-2 text-xs text-muted-foreground">Direct connection between selected locations</p></div><div className="relative overflow-hidden rounded-2xl border border-primary/35 bg-primary/10 p-5"><div className="absolute right-0 top-0 h-20 w-20 rounded-full bg-primary/15 blur-2xl" /><div className="relative flex items-center justify-between"><Leaf className="h-5 w-5 text-primary" /><span className="text-[10px] font-bold uppercase tracking-wider text-primary">Recommended</span></div><p className="relative mt-5 text-lg font-semibold">Safer route</p><p className="relative mt-1 text-sm text-muted-foreground">{routeBaseDistance + 7} km · {Math.max(1, Math.round((routeBaseDistance + 7) / 31))} hr {Math.round(((routeBaseDistance + 7) % 31) * 1.8)} min</p><div className="relative mt-5 h-1.5 overflow-hidden rounded-full bg-secondary"><div className="h-full rounded-full bg-primary" style={{ width: `${Math.max(12, routeExposure - 35)}%` }} /></div><p className="relative mt-2 text-xs text-muted-foreground">Slightly longer, lower estimated exposure</p></div></> : <div className="col-span-full grid min-h-[220px] place-items-center rounded-2xl border border-dashed border-border bg-secondary/30 p-5 text-center"><div><Route className="mx-auto h-7 w-7 text-primary" /><p className="mt-3 text-sm font-medium">Route details are ready to calculate</p><p className="mt-1 text-xs text-muted-foreground">Confirm your starting point and destination.</p></div></div>}</div></div><div className="mt-7 border-t border-border pt-6"><EvacuationRouteCard location={selected} data={emergency} route={evacRoute} onGenerate={generateEvacuationRoute} /></div></div></section>

    <section className="mx-auto max-w-7xl px-4 pb-12 sm:px-6"><div className="grid gap-5 lg:grid-cols-[1.05fr_.95fr]"><PopulationRisk location={selected} data={emergency} level={level} /><RoadStatusList data={emergency} /></div></section>

    <section className="mx-auto max-w-7xl px-4 pb-12 sm:px-6"><WeatherConditions location={selected} data={emergency} /></section>

    <section className="mx-auto max-w-7xl px-4 pb-12 sm:px-6"><div className="grid gap-5 lg:grid-cols-[1.25fr_.75fr]"><div className="rounded-3xl border border-border bg-card p-6 shadow-retool-sm"><div className="flex flex-wrap items-center justify-between gap-4"><SectionTitle eyebrow="Historical indicators" title="Last 7 days" /><Tabs value={trend} onValueChange={(value) => setTrend(value as typeof trend)}><TabsList className="bg-secondary"><TabsTrigger value="rainfall" className="text-xs">Rainfall</TabsTrigger><TabsTrigger value="moisture" className="text-xs">Soil</TabsTrigger><TabsTrigger value="risk" className="text-xs">Risk score</TabsTrigger></TabsList></Tabs></div><div className="mt-6 h-64"><ResponsiveContainer width="100%" height="100%"><AreaChart data={trendData} margin={{ top: 10, right: 10, left: -22, bottom: 0 }}><defs><linearGradient id="trendFill" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stopColor="hsl(var(--primary))" stopOpacity={0.35} /><stop offset="100%" stopColor="hsl(var(--primary))" stopOpacity={0} /></linearGradient></defs><CartesianGrid vertical={false} stroke="hsl(var(--border))" strokeDasharray="3 3" /><XAxis dataKey="day" tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 11 }} axisLine={false} tickLine={false} /><YAxis tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 11 }} axisLine={false} tickLine={false} /><Tooltip contentStyle={{ background: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: 12, fontSize: 12 }} /><Area type="monotone" dataKey={trend} name={trend === 'risk' ? 'Risk score' : trend === 'rainfall' ? 'Rainfall (mm)' : 'Soil moisture (%)'} stroke="hsl(var(--primary))" strokeWidth={2.5} fill="url(#trendFill)" /></AreaChart></ResponsiveContainer></div></div><section id="alerts" className="rounded-3xl border border-border bg-card p-6 shadow-retool-sm"><SectionTitle eyebrow="Alerts console" title="Field notification" /><div className={`mt-6 rounded-2xl border p-4 ${tone.soft}`}><div className="flex gap-3"><AlertTriangle className={`mt-0.5 h-5 w-5 shrink-0 ${tone.text}`} /><div><p className={`text-xs font-bold uppercase tracking-wider ${tone.text}`}>{level === 'LOW' ? 'Monitoring advisory' : `Landslide ${level} warning`}</p><p className="mt-2 text-sm font-medium">{level === 'LOW' ? 'Conditions stable in selected region.' : `Elevated risk detected near ${selected.name}.`}</p><p className="mt-2 text-xs leading-5 text-muted-foreground">{selected.rainfall >= 100 ? 'Heavy rainfall' : 'Recent rainfall'}, {selected.moisture >= 60 ? 'high soil moisture' : 'changing soil conditions'}, and {selected.slope >= 30 ? 'steep terrain' : 'terrain slope'} are contributing conditions.</p></div></div></div><div className="mt-5 space-y-3 text-xs"><div className="flex justify-between border-b border-border pb-3"><span className="text-muted-foreground">Severity</span><span className={`font-bold ${tone.text}`}>{level}</span></div><div className="flex justify-between"><span className="text-muted-foreground">Action</span><span className="max-w-[190px] text-right font-medium">Review suggested route before travel</span></div></div></section></div></section>

    <section id="about" className="border-y border-border bg-card/40"><div className="mx-auto max-w-7xl px-4 py-14 sm:px-6"><div className="grid gap-10 lg:grid-cols-[.8fr_1.2fr]"><div><p className="text-[10px] font-bold uppercase tracking-[0.2em] text-primary">Prototype model architecture</p><h2 className="mt-3 text-3xl font-semibold tracking-tight">From observations to safer decisions.</h2><p className="mt-4 text-sm leading-6 text-muted-foreground">LandslideGuard AI explores how environmental data, geospatial context and explainable machine learning can support early risk awareness in the North Eastern Region.</p></div><div className="grid gap-3 sm:grid-cols-3">{[[CloudRain, 'Environmental data'], [Cpu, 'Data processing'], [Bot, 'AI risk model'], [Activity, 'Risk probability'], [Sparkles, 'Explainable AI'], [MapPin, 'Map, warning & routes']].map(([Icon, text]) => { const FlowIcon = Icon as typeof CloudRain; return <div key={String(text)} className="relative rounded-2xl border border-border bg-background/60 p-4"><FlowIcon className="h-5 w-5 text-primary" /><p className="mt-4 text-sm font-medium">{String(text)}</p></div> })}</div></div><div className="mt-10 grid gap-4 border-t border-border pt-8 md:grid-cols-2"><div><p className="text-sm font-semibold">Data behind the prediction</p><p className="mt-2 text-xs leading-5 text-muted-foreground">Weather & rainfall, soil moisture, digital elevation / terrain, satellite-derived information and historical landslide data are intended data categories. No real-time source is claimed in this demo.</p></div><div><p className="text-sm font-semibold">Designed for responsible use</p><p className="mt-2 text-xs leading-5 text-muted-foreground">A real deployment would require validated datasets, domain expertise, real-time data partnerships and extensive field testing. Model approach: Random Forest using rainfall, moisture, slope, elevation, land cover and historical occurrence.</p></div></div></div></section>
    <footer className="mx-auto flex max-w-7xl flex-col gap-3 px-4 py-7 text-xs text-muted-foreground sm:flex-row sm:items-center sm:justify-between sm:px-6"><p>© 2025 LandslideGuard AI · Hackathon prototype</p><p>Estimated risk · Decision support · Demonstration data only</p></footer>
  </main>
}
