import { useMemo, useState } from 'react'
import { Check, Copy, Megaphone } from 'lucide-react'
import { Button } from '../../lib/shadcn/button'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '../../lib/shadcn/dialog'
import { riskTone, type EmergencyData, type LocationInput, type RiskLevel } from '../data/emergencyData'

// Item 9 — generates a warning message preview. Nothing is actually sent.
export default function AlertGenerator({ location, data, level }: { location: LocationInput; data: EmergencyData; level: RiskLevel }) {
  const tone = riskTone(level)
  const [copied, setCopied] = useState(false)
  const blocked = data.roads.filter((road) => road.status !== 'Open')
  const destination = data.camps[0]?.name ?? `${location.name} District Relief Camp`

  const message = useMemo(() => {
    if (level === 'LOW' || level === 'MODERATE') {
      return [
        `LANDSLIDE ADVISORY — ${level} RISK · ${location.name}, ${location.state} (DEMO)`,
        `Modelled landslide probability is ${location.risk}% after ${location.rainfall} mm of recent rainfall.`,
        `Main hazard: ${location.slope >= 30 ? 'steep, saturated slopes' : 'changing slope conditions'} with ${location.moisture}% soil moisture.`,
        `Areas to avoid: ${blocked.length > 0 ? blocked.map((road) => road.name).join('; ') : 'steep cuts and stream-adjacent roads during rain'}.`,
        `Recommended action: monitor updates, avoid hillside cuts during heavy rain, keep emergency numbers handy.`,
        `This is a simulated prototype alert — not an official warning.`,
      ].join('\n')
    }
    return [
      `LANDSLIDE WARNING — ${level} RISK · ${location.name}, ${location.state} (DEMO)`,
      `Heavy rainfall (${location.rainfall} mm) and unstable slopes have increased landslide risk in the affected zone (~${data.affectedAreaKm2} km², ${data.population.total.toLocaleString()} people est.).`,
      `Areas to avoid: ${blocked.length > 0 ? blocked.map((road) => road.name).join('; ') : 'all marked high-risk roads'}.`,
      `Move toward the designated safe zone and report to ${destination} (~${data.camps[0]?.distanceKm ?? 5} km).`,
      `Immediate instructions: keep away from hillside edges, follow marked evacuation route, cooperate with response teams, call 1078 / 108 for emergencies.`,
      `This is a simulated prototype alert — not an official warning.`,
    ].join('\n')
  }, [level, location, data, blocked, destination])

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(message)
      setCopied(true)
      window.setTimeout(() => setCopied(false), 1800)
    } catch {
      setCopied(false)
    }
  }

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button className={`h-10 rounded-xl text-xs font-bold ${tone.soft} ${tone.text} border hover:bg-red-400/15`}>
          <Megaphone className="mr-2 h-3.5 w-3.5" />📢 Generate Emergency Alert
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="text-base">📢 Generated emergency alert (demo)</DialogTitle>
          <DialogDescription>Preview text for the prototype alert pipeline. Nothing is sent via SMS or email in this build.</DialogDescription>
        </DialogHeader>
        <div className={`rounded-2xl border p-4 text-xs leading-6 ${tone.soft}`}>
          <pre className="whitespace-pre-wrap font-sans">{message}</pre>
        </div>
        <div className="flex items-center justify-between">
          <p className="text-[10px] text-muted-foreground">Demo content · no messages are dispatched.</p>
          <Button onClick={copy} variant="outline" className="h-9 rounded-xl text-xs">
            {copied ? <Check className="mr-2 h-3.5 w-3.5 text-emerald-400" /> : <Copy className="mr-2 h-3.5 w-3.5" />}{copied ? 'Copied' : 'Copy alert text'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
