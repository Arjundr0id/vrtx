import { useState } from 'react'
import {
  AlertTriangle, BedDouble, Bus, Flame, Phone, Radio, ShieldAlert, Tent, Users,
} from 'lucide-react'
import { Button } from '../../lib/shadcn/button'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '../../lib/shadcn/dialog'
import { riskTone, type EmergencyData, type Facility, type LocationInput, type RiskLevel } from '../data/emergencyData'
import AlertGenerator from './AlertGenerator'

const responseLevel: Record<RiskLevel, string> = {
  LOW: 'Level 0 · Routine monitoring',
  MODERATE: 'Level 1 · Watch & advise',
  HIGH: 'Level 2 · Partial activation',
  EXTREME: 'Level 3 · Full emergency activation',
}

const alertStatus: Record<RiskLevel, string> = {
  LOW: 'No active alert',
  MODERATE: 'Advisory issued',
  HIGH: 'Warning issued — orange',
  EXTREME: 'Critical alert — red',
}

function FacilityCard({ facility, icon: Icon, toneText }: { facility: Facility; icon: typeof Tent; toneText: string }) {
  return (
    <div className="rounded-xl border border-border bg-secondary/40 p-3">
      <div className="flex items-start justify-between gap-2">
        <p className="text-sm font-semibold leading-5">{facility.name}</p>
        <Icon className={`h-4 w-4 shrink-0 ${toneText}`} />
      </div>
      <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted-foreground">
        <span>📍 {facility.distanceKm} km away</span>
        <span>🚐 ~{facility.travelMin} min travel (demo)</span>
      </div>
      <div className="mt-2 flex flex-wrap items-center gap-2 text-[11px]">
        <span className="rounded-md border border-border bg-background/60 px-1.5 py-0.5 font-medium">{facility.status}</span>
        {facility.capacity && <span className="text-muted-foreground">{facility.capacity}</span>}
      </div>
    </div>
  )
}

function FacilityDialog({ facilityList, icon: Icon, title, intro }: { facilityList: Facility[]; icon: typeof Tent; title: string; intro: string }) {
  const toneText = 'text-primary'
  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline" className="h-auto w-full flex-col items-start gap-1.5 rounded-2xl border-border bg-secondary/40 p-4 text-left hover:border-primary/40">
          <span className="flex w-full items-center justify-between">
            <span className="flex items-center gap-2 text-sm font-semibold"><Icon className={`h-4 w-4 ${toneText}`} />{title}</span>
            <span className="rounded-md bg-background px-1.5 py-0.5 text-[10px] font-bold text-muted-foreground">{facilityList.length}</span>
          </span>
          <span className="text-left text-[11px] leading-4 text-muted-foreground">{intro}</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="max-h-[80vh] max-w-lg overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-base">{title} — demo directory</DialogTitle>
          <DialogDescription>Simulated prototype entries — {intro} Not live facility data.</DialogDescription>
        </DialogHeader>
        <div className="space-y-2.5">{facilityList.map((facility) => <FacilityCard key={facility.name} facility={facility} icon={Icon} toneText={toneText} />)}</div>
      </DialogContent>
    </Dialog>
  )
}

// Item 1 — Emergency Response Hub. Rendered only for HIGH / EXTREME risk.
export default function EmergencyHub({ location, data, level }: { location: LocationInput; data: EmergencyData; level: RiskLevel }) {
  const tone = riskTone(level)
  const [contactsOpen, setContactsOpen] = useState(false)
  const nearestCamp = [...data.camps].sort((a, b) => a.distanceKm - b.distanceKm)[0]

  return (
    <section aria-label="Emergency response hub" className="rounded-3xl border border-red-400/30 bg-red-400/[0.04] p-6 shadow-retool-md sm:p-7">
      <div className="pointer-events-none relative -mb-3 flex justify-end"><span className="absolute right-0 top-0 h-24 w-24 rounded-full bg-red-400/10 blur-2xl" /></div>
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <p className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.2em] text-red-400"><span className="h-1.5 w-1.5 animate-pulse rounded-full bg-red-400" />Emergency response</p>
          <h2 className="mt-1.5 text-2xl font-semibold tracking-tight">🚨 Emergency Response Hub</h2>
          <p className="mt-1 text-xs text-muted-foreground">Simulated emergency coordination view for {location.name}, {location.state}.</p>
        </div>
        <AlertGenerator location={location} data={data} level={level} />
      </div>

      <div className="mt-5 grid gap-2.5 sm:grid-cols-2 xl:grid-cols-5">
        {[
          { icon: ShieldAlert, label: 'Current risk level', value: `${level} · ${location.risk}%`, tone: tone.text },
          { icon: Radio, label: 'Alert status', value: alertStatus[level], tone: tone.text },
          { icon: Users, label: 'Population at risk', value: `${data.population.total.toLocaleString()} (est.)`, tone: undefined },
          { icon: AlertTriangle, label: 'Affected area', value: `${data.affectedAreaKm2} km² (est.)`, tone: undefined },
          { icon: Flame, label: 'Response level', value: responseLevel[level], tone: tone.text },
        ].map((item) => (
          <div key={item.label} className={`rounded-2xl border p-3.5 ${tone.soft} bg-card/40`}>
            <item.icon className={`h-4 w-4 ${item.tone ?? 'text-muted-foreground'}`} />
            <p className="mt-2.5 text-[10px] font-bold uppercase tracking-wider text-muted-foreground">{item.label}</p>
            <p className="mt-1 text-sm font-semibold leading-5">{item.value}</p>
          </div>
        ))}
      </div>

      <p className="mt-6 mb-2 text-[10px] font-bold uppercase tracking-[0.16em] text-muted-foreground">Respond · nearby capabilities (demo data)</p>
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        <FacilityDialog facilityList={data.camps} icon={Tent} title="🏕️ Nearest Relief Camps" intro={`relief camps around ${location.name}`} />
        <FacilityDialog facilityList={data.hospitals} icon={BedDouble} title="🏥 Nearest Hospitals" intro={`hospitals serving ${location.name}`} />
        <FacilityDialog facilityList={data.fire} icon={Flame} title="🚒 Rescue & Emergency Services" intro="fire and rescue stations." />
        <FacilityDialog facilityList={data.teams} icon={Users} title="🚁 Rescue / Response Teams" intro="specialist response teams." />
        <Dialog open={contactsOpen} onOpenChange={setContactsOpen}>
          <DialogTrigger asChild>
            <Button variant="outline" className="h-auto w-full flex-col items-start gap-1.5 rounded-2xl border-border bg-secondary/40 p-4 text-left hover:border-primary/40">
              <span className="flex w-full items-center justify-between">
                <span className="flex items-center gap-2 text-sm font-semibold"><Phone className="h-4 w-4 text-primary" />📞 Emergency Contacts</span>
                <span className="rounded-md bg-background px-1.5 py-0.5 text-[10px] font-bold text-muted-foreground">{data.contacts.length}</span>
              </span>
              <span className="text-left text-[11px] leading-4 text-muted-foreground">Standard emergency helplines for coordination.</span>
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle className="text-base">📞 Emergency Contacts</DialogTitle>
              <DialogDescription>Standard national helplines shown as prototype reference data.</DialogDescription>
            </DialogHeader>
            <div className="space-y-2">{data.contacts.map((contact) => (
              <div key={contact.number} className="flex items-center justify-between gap-3 rounded-xl border border-border bg-secondary/40 px-3 py-2.5">
                <div><p className="text-sm font-medium">{contact.name}</p><p className="text-[11px] text-muted-foreground">{contact.note}</p></div>
                <span className="rounded-lg bg-primary/10 px-2.5 py-1 font-mono text-sm font-bold text-primary">{contact.number}</span>
              </div>
            ))}</div>
          </DialogContent>
        </Dialog>
        {nearestCamp && (
          <div className="rounded-2xl border border-primary/30 bg-primary/10 p-4">
            <span className="flex items-center gap-2 text-sm font-semibold"><Bus className="h-4 w-4 text-primary" />🧭 Go-to safe location</span>
            <p className="mt-1 text-[11px] leading-4 text-muted-foreground">{nearestCamp.name} · {nearestCamp.distanceKm} km · generate the AI evacuation route below the map.</p>
          </div>
        )}
      </div>
      <p className="mt-4 text-[10px] text-muted-foreground">All facility names, distances, capacities and statuses on this page are DEMO DATA for hackathon demonstration — not real-time information.</p>
    </section>
  )
}
