import { Ban, Leaf, Navigation, Route, ShieldCheck } from 'lucide-react'
import { Button } from '../../lib/shadcn/button'
import type { EmergencyData, EvacuationRoute, LocationInput } from '../data/emergencyData'

type Props = {
  location: LocationInput
  data: EmergencyData
  route: EvacuationRoute | null
  onGenerate: () => void
}

// Item 3 — AI evacuation route generator, complements the existing safer-route comparison.
export default function EvacuationRouteCard({ location, data, route, onGenerate }: Props) {
  return (
    <div className="rounded-2xl border border-primary/30 bg-primary/[0.06] p-5">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <p className="text-[10px] font-bold uppercase tracking-[0.18em] text-primary">AI evacuation routing</p>
          <h3 className="mt-1 text-lg font-semibold">🧭 Safe Evacuation Route</h3>
          <p className="mt-1 max-w-md text-xs leading-5 text-muted-foreground">Generates a demo path from {location.name} toward the designated safe zone, steering around modelled landslide zones, high-risk areas and blocked roads.</p>
        </div>
        <Button onClick={onGenerate} className="h-10 rounded-xl text-xs font-bold">
          🧭 Generate Safe Evacuation Route <Navigation className="ml-2 h-4 w-4" />
        </Button>
      </div>

      {route ? (
        <div className="mt-5 grid gap-3 sm:grid-cols-3">
          <div className="rounded-xl border border-emerald-400/30 bg-emerald-400/10 p-4 sm:col-span-1">
            <Route className="h-5 w-5 text-emerald-400" />
            <p className="mt-3 text-xs font-bold uppercase tracking-wider text-emerald-400">Recommended route</p>
            <p className="mt-1 text-sm font-semibold leading-5">{route.originName} → {route.destination}</p>
            <p className="mt-2 text-xs text-muted-foreground">{route.distanceKm} km · ~{route.travelMin} min travel (demo)</p>
            <div className="mt-3 flex items-center gap-1.5 text-[11px] text-muted-foreground"><ShieldCheck className="h-3.5 w-3.5 text-emerald-400" />Rendered on the map in green</div>
          </div>
          <div className="rounded-xl border border-border bg-secondary/40 p-4 sm:col-span-1">
            <Ban className="h-5 w-5 text-red-400" />
            <p className="mt-3 text-xs font-bold uppercase tracking-wider text-muted-foreground">Avoided on this route</p>
            <ul className="mt-2 space-y-1 text-xs text-muted-foreground">
              {route.avoided.slice(0, 5).map((item) => <li key={item} className="flex gap-1.5"><span className="text-red-400">✕</span>{item}</li>)}
            </ul>
          </div>
          <div className="rounded-xl border border-border bg-secondary/40 p-4 sm:col-span-1">
            <Leaf className="h-5 w-5 text-primary" />
            <p className="mt-3 text-xs font-bold uppercase tracking-wider text-muted-foreground">Destination & notes</p>
            <p className="mt-2 text-xs leading-5 text-muted-foreground">Ends at <span className="font-medium text-foreground">{route.destination}</span> with estimated capacity {data.camps[0]?.capacity ?? '—'}.</p>
            <p className="mt-2 text-[10px] leading-4 text-muted-foreground">{route.notes}</p>
          </div>
        </div>
      ) : (
        <p className="mt-4 rounded-xl border border-dashed border-border bg-secondary/30 px-4 py-3 text-xs text-muted-foreground">No evacuation route generated yet. Press the button to compute the demo safe path — it will also be drawn on the regional map.</p>
      )}
    </div>
  )
}
