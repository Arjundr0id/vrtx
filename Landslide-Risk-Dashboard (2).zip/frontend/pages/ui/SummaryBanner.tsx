import { Activity, Ban, BedDouble, MapPinned, Route, Tent, Users } from 'lucide-react'
import { getRiskLevel, riskTone, type EmergencyData, type LocationInput, type RiskLevel } from '../data/emergencyData'

type Props = {
  location: LocationInput
  data: EmergencyData
  routeAvailable: boolean
}

function Stat({ icon: Icon, label, value, tone }: { icon: typeof Users; label: string; value: string; tone?: string | undefined }) {
  return (
    <div className="rounded-xl border border-border bg-secondary/40 px-3 py-2.5">
      <div className="flex items-center gap-1.5 text-[9px] font-bold uppercase tracking-[0.14em] text-muted-foreground">
        <Icon className={`h-3 w-3 ${tone ?? 'text-muted-foreground'}`} /> {label}
      </div>
      <p className={`mt-1 text-sm font-semibold ${tone ?? 'text-foreground'}`}>{value}</p>
    </div>
  )
}

// Item 10 — Dashboard summary strip shown at the top of the page.
export default function SummaryBanner({ location, data, routeAvailable }: Props) {
  const level: RiskLevel = getRiskLevel(location.risk)
  const tone = riskTone(level)
  const critical = level === 'HIGH' || level === 'EXTREME'
  const nearestCamp = [...data.camps].sort((a, b) => a.distanceKm - b.distanceKm)[0]
  const nearestHospital = [...data.hospitals].sort((a, b) => a.distanceKm - b.distanceKm)[0]
  const roadsBlocked = data.roads.filter((road) => road.status === 'Blocked / Unsafe').length

  return (
    <section aria-label="Landslide status summary" className="rounded-3xl border border-border bg-card/70 shadow-retool-md backdrop-blur">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border/70 px-5 py-3.5">
        <div className="flex items-center gap-2.5">
          <span className={`grid h-8 w-8 place-items-center rounded-xl ${tone.soft}`}>
            <Activity className={`h-4 w-4 ${tone.text}`} />
          </span>
          <p className="text-sm font-bold tracking-tight">LANDSLIDE STATUS <span className="ml-1 rounded-md bg-secondary px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wider text-muted-foreground">demo snapshot</span></p>
        </div>
        <div className="flex items-center gap-2 text-xs">
          <span className="text-muted-foreground">Recommended action:</span>
          <span className={`rounded-lg border px-2.5 py-1 text-[11px] font-bold uppercase tracking-wider ${tone.soft} ${tone.text}`}>
            {critical ? (level === 'EXTREME' ? 'IMMEDIATE EVACUATION' : 'PREPARE FOR EVACUATION') : 'MONITOR CONDITIONS'}
          </span>
        </div>
      </div>
      <div className="grid grid-cols-2 gap-2.5 px-5 py-4 sm:grid-cols-3 xl:grid-cols-7">
        <Stat icon={Activity} label="Risk" value={`${level} · ${location.risk}%`} tone={tone.text} />
        <Stat icon={MapPinned} label="Affected area" value={`${data.affectedAreaKm2} km²`} />
        <Stat icon={Users} label="Population at risk" value={data.population.total.toLocaleString()} />
        <Stat icon={Route} label="Safe route" value={routeAvailable ? 'Available' : 'Not generated'} tone={routeAvailable ? 'text-emerald-400' : undefined} />
        <Stat icon={Tent} label="Nearest relief camp" value={nearestCamp ? `${nearestCamp.distanceKm} km` : '—'} />
        <Stat icon={BedDouble} label="Nearest hospital" value={nearestHospital ? `${nearestHospital.distanceKm} km` : '—'} />
        <Stat icon={Ban} label="Roads blocked" value={String(roadsBlocked)} tone={roadsBlocked > 0 ? 'text-red-400' : 'text-emerald-400'} />
      </div>
      <p className="px-5 pb-3.5 text-[10px] text-muted-foreground">All figures in this strip are simulated prototype estimates for the selected location — not live measurements.</p>
    </section>
  )
}
