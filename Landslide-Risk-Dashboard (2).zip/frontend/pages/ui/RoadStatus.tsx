import { Ban, Circle, Triangle } from 'lucide-react'
import { cn } from '../../lib/shadcn/utils'
import { type EmergencyData } from '../data/emergencyData'

const statusStyle = {
  Open: { chip: 'border-emerald-400/30 bg-emerald-400/10 text-emerald-400', icon: Circle },
  'Partially Blocked': { chip: 'border-orange-400/30 bg-orange-400/10 text-orange-400', icon: Triangle },
  'Blocked / Unsafe': { chip: 'border-red-400/30 bg-red-400/10 text-red-400', icon: Ban },
} as const

// Item 7 — road & infrastructure status list; feeds the same data the evacuation route avoids.
export default function RoadStatusList({ data }: { data: EmergencyData }) {
  return (
    <section aria-label="Road and infrastructure status" className="rounded-3xl border border-border bg-card p-6 shadow-retool-sm">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <p className="text-[10px] font-bold uppercase tracking-[0.18em] text-primary">Access intelligence · demo status</p>
          <h2 className="mt-1 text-xl font-semibold tracking-tight">🚧 Road & Infrastructure Status</h2>
        </div>
        <div className="flex gap-2 text-[10px] font-semibold">
          <span className="rounded-md border border-emerald-400/30 bg-emerald-400/10 px-2 py-1 text-emerald-400">🟢 Open</span>
          <span className="rounded-md border border-orange-400/30 bg-orange-400/10 px-2 py-1 text-orange-400">🟠 Partially blocked</span>
          <span className="rounded-md border border-red-400/30 bg-red-400/10 px-2 py-1 text-red-400">🔴 Blocked / unsafe</span>
        </div>
      </div>

      <div className="mt-5 space-y-2.5">
        {data.roads.map((road) => {
          const style = statusStyle[road.status]
          const Icon = style.icon
          return (
            <div key={road.name} className="rounded-xl border border-border bg-secondary/40 p-3.5 transition hover:border-primary/30">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <p className="flex items-center gap-2 text-sm font-semibold"><Icon className={cn('h-3.5 w-3.5', style.chip.split(' ').find((cls) => cls.startsWith('text-')))} />{road.name}</p>
                <span className={cn('rounded-md border px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider', style.chip)}>{road.status}</span>
              </div>
              <div className="mt-2 grid gap-1 text-[11px] text-muted-foreground sm:grid-cols-2">
                <p><span className="font-semibold text-foreground">Reason:</span> {road.reason} (demo)</p>
                <p><span className="font-semibold text-foreground">Alternative:</span> {road.alternative}</p>
              </div>
            </div>
          )
        })}
      </div>
      <p className="mt-4 text-[10px] text-muted-foreground">Simulated road statuses. The AI evacuation route automatically avoids roads marked Blocked / Unsafe in this demo.</p>
    </section>
  )
}
