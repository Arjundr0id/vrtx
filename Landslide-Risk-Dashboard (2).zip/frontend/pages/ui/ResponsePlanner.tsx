import { Ambulance, Bot, CheckCircle2, Flame, HardHat, Tent, Users } from 'lucide-react'
import { useState } from 'react'
import { type EmergencyData, type LocationInput, type RiskLevel } from '../data/emergencyData'

const ACTIONS: Record<RiskLevel, string[]> = {
  EXTREME: [
    '🚨 Alert people inside the high-risk zone (sirens, SMS cells, community leaders)',
    '🚧 Restrict traffic on all marked unsafe roads immediately',
    '🏕️ Activate the nearest relief camp and open assembly points',
    '🏥 Notify and prep nearby medical facilities for mass intake',
    '🚒 Dispatch rescue personnel and stage equipment near the zone',
    '🧭 Push the recommended evacuation route to field teams and residents',
  ],
  HIGH: [
    '🚨 Issue early warnings to settlements in the affected zone',
    '🚧 Prepare to restrict traffic on roads flagged as blocked or unsafe',
    '🏕️ Keep the nearest relief camp on standby for activation',
    '🏥 Alert nearby medical facilities to review capacity',
    '🚒 Place rescue personnel on short-notice standby',
    '🧭 Share the recommended evacuation route with residents',
  ],
  MODERATE: [
    '📡 Increase monitoring frequency of rainfall and soil sensors',
    '🚧 Inspect flagged road sections after each heavy rain spell',
    '🏕️ Verify readiness of relief camps and supplies',
    '📢 Send advisory messages to communities near steep slopes',
  ],
  LOW: [
    '📡 Continue routine monitoring of environmental indicators',
    '🗂️ Review emergency contact lists and camp readiness quarterly',
  ],
}

// Item 8 — generated response checklist + resource estimate (demo logic).
export default function ResponsePlanner({ location, data, level }: { location: LocationInput; data: EmergencyData; level: RiskLevel }) {
  const [checked, setChecked] = useState<Record<number, boolean>>({})
  const actions = ACTIONS[level]
  const atRisk = data.population.immediate + data.population.prepare
  const personnel = Math.max(12, Math.round(atRisk / 120))
  const ambulances = Math.max(2, Math.round(atRisk / 900))
  const reliefCapacity = Math.round(atRisk * 1.15)
  const equipment = Math.max(3, Math.round(personnel / 6))

  const resources = [
    { icon: Users, label: 'Rescue personnel', value: `${personnel} (demo)`, sub: '~1 responder per 120 evacuees' },
    { icon: Ambulance, label: 'Ambulances', value: `${ambulances} (demo)`, sub: '~1 per 900 people at risk' },
    { icon: Tent, label: 'Relief capacity', value: `${reliefCapacity.toLocaleString()} beds (demo)`, sub: '115% of at-risk population' },
    { icon: HardHat, label: 'Emergency equipment', value: `${equipment} kits (demo)`, sub: 'Rope, cutting, medical kits' },
  ]

  return (
    <section aria-label="AI emergency response plan" className="rounded-3xl border border-border bg-card p-6 shadow-retool-sm">
      <div className="flex items-center gap-2.5">
        <span className="grid h-9 w-9 place-items-center rounded-xl bg-secondary"><Bot className="h-4 w-4 text-primary" /></span>
        <div>
          <p className="text-[10px] font-bold uppercase tracking-[0.18em] text-primary">Generated from current risk, population and access data</p>
          <h2 className="text-xl font-semibold tracking-tight">🤖 AI Emergency Response Plan</h2>
        </div>
      </div>

      <p className="mt-3 text-sm text-muted-foreground">Suggested checklist for <span className="font-medium text-foreground">{location.name}</span> at {level} risk. Prototype logic — confirm with official emergency procedures.</p>

      <p className="mt-5 mb-2 text-[10px] font-bold uppercase tracking-[0.16em] text-muted-foreground">Immediate actions · tick to track (demo)</p>
      <div className="space-y-2">
        {actions.map((action, index) => (
          <button key={action} onClick={() => setChecked((current) => ({ ...current, [index]: !current[index] }))} className={`flex w-full items-center gap-3 rounded-xl border p-3 text-left transition ${checked[index] ? 'border-emerald-400/40 bg-emerald-400/[0.07]' : 'border-border bg-secondary/40 hover:border-primary/30'}`} aria-pressed={Boolean(checked[index])}>
            <span className={`grid h-5 w-5 shrink-0 place-items-center rounded-md border ${checked[index] ? 'border-emerald-400/60 bg-emerald-400/15' : 'border-border bg-background'}`}>
              {checked[index] ? <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" /> : <span className="text-[10px] font-bold text-muted-foreground">{index + 1}</span>}
            </span>
            <span className={`text-sm ${checked[index] ? 'text-muted-foreground line-through decoration-emerald-400/60' : ''}`}>{action}</span>
          </button>
        ))}
      </div>

      <p className="mt-6 mb-2 flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.16em] text-muted-foreground"><Flame className="h-3.5 w-3.5 text-primary" />Estimated resource requirements (demo figures)</p>
      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        {resources.map((item) => (
          <div key={item.label} className="rounded-xl border border-border bg-secondary/40 p-3.5">
            <item.icon className="h-4 w-4 text-primary" />
            <p className="mt-2 text-[10px] font-bold uppercase tracking-wider text-muted-foreground">{item.label}</p>
            <p className="mt-1 text-lg font-semibold">{item.value}</p>
            <p className="mt-0.5 text-[10px] text-muted-foreground">{item.sub}</p>
          </div>
        ))}
      </div>
    </section>
  )
}
