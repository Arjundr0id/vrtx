import { CloudRain, Droplets, Thermometer, TrendingUp } from 'lucide-react'
import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { type EmergencyData, type LocationInput } from '../data/emergencyData'

// Item 6 — compact environmental conditions panel with a 24h rainfall trend (demo data).
export default function WeatherConditions({ location, data }: { location: LocationInput; data: EmergencyData }) {
  const trend = data.rainfallForecast.map((point, index) => ({
    ...point,
    cumulative: data.rainfallForecast.slice(0, index + 1).reduce((sum, item) => sum + item.rain, 0),
  }))
  const rising = trend.length > 3 && trend[3]!.rain > trend[0]!.rain

  return (
    <section aria-label="Environmental conditions" className="rounded-3xl border border-border bg-card p-6 shadow-retool-sm">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <p className="text-[10px] font-bold uppercase tracking-[0.18em] text-primary">Environmental watch · demo data</p>
          <h2 className="mt-1 text-xl font-semibold tracking-tight">🌧️ Environmental Conditions</h2>
        </div>
        <span className="rounded-lg border border-border bg-secondary/60 px-2 py-1 text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Simulated forecast</span>
      </div>

      <div className="mt-5 grid grid-cols-2 gap-3 lg:grid-cols-4">
        {[
          { icon: CloudRain, label: 'Current rainfall', value: `${data.currentRainfallMm} mm`, sub: 'Last 24 hours (demo)' },
          { icon: TrendingUp, label: 'Expected rainfall', value: `${data.expectedRainfallMm} mm`, sub: 'Next 24 hours (demo)' },
          { icon: Droplets, label: 'Soil moisture', value: `${location.moisture}%`, sub: 'Near-surface estimate' },
          { icon: Thermometer, label: 'Temperature', value: `${data.temperatureC}°C`, sub: 'Simulated reading' },
        ].map((item) => (
          <div key={item.label} className="rounded-xl border border-border bg-secondary/40 p-3.5">
            <item.icon className="h-4 w-4 text-primary" />
            <p className="mt-2 text-[10px] font-bold uppercase tracking-wider text-muted-foreground">{item.label}</p>
            <p className="mt-1 text-xl font-semibold">{item.value}</p>
            <p className="mt-0.5 text-[10px] text-muted-foreground">{item.sub}</p>
          </div>
        ))}
      </div>

      <p className="mt-5 mb-1 text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Rainfall trend · next 24 hours {rising ? '↑ rising' : '· easing'}</p>
      <div className="h-44">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={trend} margin={{ top: 8, right: 8, left: -24, bottom: 0 }}>
            <defs>
              <linearGradient id="rainFill" x1="0" x2="0" y1="0" y2="1">
                <stop offset="0%" stopColor="hsl(var(--chart-5))" stopOpacity={0.4} />
                <stop offset="100%" stopColor="hsl(var(--chart-5))" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid vertical={false} stroke="hsl(var(--border))" strokeDasharray="3 3" />
            <XAxis dataKey="hour" tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 10 }} axisLine={false} tickLine={false} interval={1} />
            <YAxis tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 10 }} axisLine={false} tickLine={false} />
            <Tooltip contentStyle={{ background: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: 12, fontSize: 12 }} />
            <Area type="monotone" dataKey="rain" name="Rainfall (mm/2h)" stroke="hsl(var(--chart-5))" strokeWidth={2.5} fill="url(#rainFill)" />
          </AreaChart>
        </ResponsiveContainer>
      </div>
      <p className="mt-2 text-[10px] text-muted-foreground">Demo forecast curve — no live weather API is connected in this prototype.</p>
    </section>
  )
}
