import { AlertTriangle, Bot, Users } from 'lucide-react'
import { type EmergencyData, type LocationInput, type RiskLevel } from '../data/emergencyData'

type Props = { location: LocationInput; data: EmergencyData; level: RiskLevel }

function Bucket({ label, count, dotClass, barClass, share }: { label: string; count: number; dotClass: string; barClass: string; share: number }) {
  return (
    <div className="rounded-xl border border-border bg-secondary/40 p-3.5">
      <div className="flex items-center gap-2 text-[11px] font-bold uppercase tracking-wider text-muted-foreground"><span className={`h-2 w-2 rounded-full ${dotClass}`} />{label}</div>
      <p className="mt-1.5 text-xl font-semibold">{count.toLocaleString()}</p>
      <div className="mt-2 h-1.5 rounded-full bg-background/60"><div className={`h-full rounded-full ${barClass}`} style={{ width: `${Math.max(4, share)}%` }} /></div>
      <p className="mt-1.5 text-[10px] text-muted-foreground">~{Math.round(share)}% of estimated exposed population</p>
    </div>
  )
}

// Item 4 — population at risk estimates plus AI evacuation priority ranking (demo).
export default function PopulationRisk({ location, data, level }: Props) {
  const total = Math.max(1, data.population.total)
  const toneByLevel = { LOW: 'text-emerald-400', MODERATE: 'text-yellow-300', HIGH: 'text-orange-400', EXTREME: 'text-red-400' }[level]

  return (
    <section aria-label="Population at risk" className="rounded-3xl border border-border bg-card p-6 shadow-retool-sm">
      <div className="flex items-center gap-2.5">
        <span className="grid h-9 w-9 place-items-center rounded-xl bg-secondary"><Users className={`h-4 w-4 ${toneByLevel}`} /></span>
        <div>
          <p className="text-[10px] font-bold uppercase tracking-[0.18em] text-primary">Impact assessment · demo estimates</p>
          <h2 className="text-xl font-semibold tracking-tight">👥 Population at Risk</h2>
        </div>
      </div>
      <p className="mt-3 text-sm text-muted-foreground">Estimated <span className="font-semibold text-foreground">{data.population.total.toLocaleString()}</span> people across ~{data.affectedAreaKm2} km² around {location.name} could be affected. These are simulated estimates, not census data.</p>

      <div className="mt-5 grid gap-3 sm:grid-cols-3">
        <Bucket label="🔴 Immediate evacuation" count={data.population.immediate} dotClass="bg-red-400" barClass="bg-red-400" share={(data.population.immediate / total) * 100} />
        <Bucket label="🟠 Prepare to evacuate" count={data.population.prepare} dotClass="bg-orange-400" barClass="bg-orange-400" share={(data.population.prepare / total) * 100} />
        <Bucket label="🟢 Low immediate risk" count={data.population.low} dotClass="bg-emerald-400" barClass="bg-emerald-400" share={(data.population.low / total) * 100} />
      </div>

      <div className="mt-6 rounded-2xl border border-primary/25 bg-primary/[0.05] p-4">
        <p className="flex items-center gap-2 text-xs font-bold uppercase tracking-[0.16em] text-primary"><Bot className="h-4 w-4" />AI Evacuation Priority</p>
        <p className="mt-2 text-xs leading-5 text-muted-foreground">Ranked by modelled landslide risk, population density, road accessibility, distance to safe zones and distance to relief facilities. Demo weighting — not a validated model.</p>
        <div className="mt-4 space-y-2.5">
          {data.priorityAreas.map((area, index) => (
            <div key={area.name} className="rounded-xl border border-border bg-card/70 p-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <p className="flex items-center gap-2 text-sm font-medium"><span className={`grid h-5 w-5 place-items-center rounded-md text-[10px] font-bold ${index === 0 ? 'bg-red-400/15 text-red-400' : index === 1 ? 'bg-orange-400/15 text-orange-400' : 'bg-secondary text-muted-foreground'}`}>{index + 1}</span>{area.name}</p>
                <span className={`text-xs font-bold ${area.priority >= 75 ? 'text-red-400' : area.priority >= 55 ? 'text-orange-400' : 'text-emerald-400'}`}>Priority {area.priority}/100</span>
              </div>
              <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-[11px] text-muted-foreground">
                <span>Risk {area.risk}%</span><span>~{area.population.toLocaleString()} people</span><span>Roads: {area.roadAccess}</span><span>Safe zone {area.distanceToSafeKm} km</span><span>Relief {area.distanceToReliefKm} km</span>
              </div>
            </div>
          ))}
        </div>
        <p className="mt-3 flex items-start gap-2 text-[10px] leading-4 text-muted-foreground"><AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-primary" />Evacuate highest-priority areas first in this simulated scenario; real prioritization requires official survey data.</p>
      </div>
    </section>
  )
}
