import { useState } from 'react'
import { BedDouble, Ban, Crosshair, Flame, MapPin, Mountain, Route, Tent, ZoomIn, ZoomOut } from 'lucide-react'
import { cn } from '../../lib/shadcn/utils'
import { getRiskLevel, riskTone, type EmergencyData, type EvacuationRoute } from '../data/emergencyData'

export type LocationData = {
  name: string
  state: string
  risk: number
  rainfall: number
  moisture: number
  slope: number
  elevation: string
  cover: string
  terrain: string
  coords: { x: string; y: string }
}

type LayerKey = 'extreme' | 'high' | 'moderate' | 'safe' | 'hospitals' | 'camps' | 'fire' | 'roads' | 'points'

const zoneColor: Record<string, { fill: string; border: string }> = {
  EXTREME: { fill: 'bg-red-400/20', border: 'border-red-400/50' },
  HIGH: { fill: 'bg-orange-400/20', border: 'border-orange-400/50' },
  MODERATE: { fill: 'bg-yellow-300/20', border: 'border-yellow-300/50' },
  SAFE: { fill: 'bg-emerald-400/15', border: 'border-emerald-400/45' },
}

const markerIcon = { hospital: BedDouble, camp: Tent, fire: Flame, blocked: Ban, point: MapPin } as const
const markerColor = { hospital: 'bg-red-400', camp: 'bg-emerald-400', fire: 'bg-orange-400', blocked: 'bg-red-500', point: 'bg-primary' } as const

type Props = {
  locations: LocationData[]
  selectedName: string
  onSelect: (name: string) => void
  route: EvacuationRoute | null
  emergency: EmergencyData
}

// Item 2 — the existing regional risk map, extended with toggleable emergency layers.
export default function RiskMap({ locations, selectedName, onSelect, route, emergency }: Props) {
  const [mapZoom, setMapZoom] = useState(1)
  const [mapLayer, setMapLayer] = useState<'risk' | 'terrain'>('risk')
  const [layers, setLayers] = useState<Record<LayerKey, boolean>>({
    extreme: true, high: true, moderate: true, safe: true, hospitals: true, camps: true, fire: false, roads: true, points: true,
  })
  const toggle = (key: LayerKey) => setLayers((current) => ({ ...current, [key]: !current[key] }))

  const selected = locations.find((location) => location.name === selectedName) ?? locations[0]
  if (!selected) return null
  const level = getRiskLevel(selected.risk)
  const tone = riskTone(level)

  const layerButtons: { key: LayerKey; label: string; dot: string }[] = [
    { key: 'extreme', label: 'Extreme zones', dot: 'bg-red-400' },
    { key: 'high', label: 'High zones', dot: 'bg-orange-400' },
    { key: 'moderate', label: 'Moderate zones', dot: 'bg-yellow-300' },
    { key: 'safe', label: 'Low-risk / safe', dot: 'bg-emerald-400' },
    { key: 'hospitals', label: 'Hospitals', dot: 'bg-red-300' },
    { key: 'camps', label: 'Relief camps', dot: 'bg-emerald-300' },
    { key: 'fire', label: 'Fire / rescue', dot: 'bg-orange-300' },
    { key: 'roads', label: 'Blocked roads', dot: 'bg-red-500' },
    { key: 'points', label: 'Key locations', dot: 'bg-primary' },
  ]

  return (
    <section id="risk-map" className="relative overflow-hidden rounded-3xl border border-border bg-card p-6 shadow-retool-sm">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="mb-1 text-[10px] font-bold uppercase tracking-[0.2em] text-primary">Geospatial intelligence</p>
          <h2 className="text-xl font-semibold tracking-tight text-foreground">Regional risk & emergency map</h2>
        </div>
        <div className="flex rounded-xl border border-border bg-secondary/60 p-1">
          <button onClick={() => setMapLayer('risk')} className={cn('rounded-lg px-2.5 py-1.5 text-[10px] font-bold transition', mapLayer === 'risk' ? 'bg-card text-primary shadow-sm' : 'text-muted-foreground')}>Risk zones</button>
          <button onClick={() => setMapLayer('terrain')} className={cn('rounded-lg px-2.5 py-1.5 text-[10px] font-bold transition', mapLayer === 'terrain' ? 'bg-card text-primary shadow-sm' : 'text-muted-foreground')}>Terrain</button>
        </div>
      </div>

      <div className="mt-4 flex flex-wrap gap-1.5">
        {layerButtons.map((button) => (
          <button key={button.key} onClick={() => toggle(button.key)} aria-pressed={layers[button.key]} className={cn('flex items-center gap-1.5 rounded-lg border px-2 py-1 text-[10px] font-semibold transition', layers[button.key] ? 'border-primary/40 bg-primary/10 text-foreground' : 'border-border bg-secondary/40 text-muted-foreground hover:text-foreground')}>
            <span className={cn('h-2 w-2 rounded-full', button.dot, !layers[button.key] && 'opacity-30')} />{button.label}
          </button>
        ))}
      </div>

      <div className="relative mt-4 h-[430px] overflow-hidden rounded-2xl border border-border bg-[#0b1d2e]">
        <div className="absolute inset-0 origin-center transition-transform duration-500 [background-image:radial-gradient(circle_at_40%_30%,rgba(42,148,126,.16),transparent_24%),linear-gradient(25deg,transparent_42%,rgba(67,100,106,.24)_42.5%,transparent_44%,transparent_56%,rgba(67,100,106,.15)_56.5%,transparent_58%),linear-gradient(120deg,transparent_40%,rgba(67,100,106,.22)_40.5%,transparent_42%,transparent_63%,rgba(67,100,106,.16)_63.5%,transparent_65%)]" style={{ transform: `scale(${mapZoom})` }}>
          <div className="absolute inset-0 opacity-25 [background-image:linear-gradient(rgba(148,163,184,.15)_1px,transparent_1px),linear-gradient(90deg,rgba(148,163,184,.15)_1px,transparent_1px)] [background-size:36px_36px]" />
          <div className={cn('absolute left-[15%] top-[18%] h-28 w-56 rotate-[-20deg] rounded-[44%_56%_48%_52%] border border-emerald-300/30 transition-all', mapLayer === 'terrain' ? 'bg-slate-400/15' : 'bg-emerald-400/10')} />
          <div className={cn('absolute left-[35%] top-[45%] h-28 w-64 rotate-[9deg] rounded-[55%_45%_60%_40%] border border-primary/25 transition-all', mapLayer === 'terrain' ? 'bg-slate-300/15' : 'bg-primary/10')} />

          {/* Emergency risk-zone layers (demo zones) */}
          {emergency.zones.map((zone) => {
            const active = zone.level === 'SAFE' ? layers.safe : layers[zone.level.toLowerCase() as LayerKey]
            if (!active) return null
            const color = zoneColor[zone.level] ?? zoneColor['SAFE']!
            return (
              <div key={zone.id} className={cn('absolute rounded-[50%_50%_45%_55%] border transition-opacity', color.fill, color.border)} style={{ left: `${zone.x}%`, top: `${zone.y}%`, width: zone.w, height: zone.h, transform: `translate(-50%,-50%) rotate(${zone.rotate}deg)` }} title={zone.label} />
            )
          })}

          {/* AI evacuation route overlay */}
          {route && (
            <svg className="absolute inset-0 z-10 h-full w-full" viewBox="0 0 100 100" preserveAspectRatio="none" aria-label="Evacuation route">
              <polyline points={route.waypoints.map((point) => `${point.x},${point.y}`).join(' ')} fill="none" stroke="#34d399" strokeWidth={0.9} strokeDasharray="2.4 1.6" strokeLinecap="round" vectorEffect="non-scaling-stroke" style={{ strokeWidth: 3.5 }} />
              {route.waypoints.map((point, index) => <circle key={index} cx={point.x} cy={point.y} r={index === route.waypoints.length - 1 ? 1.4 : 1} fill={index === 0 ? '#34d399' : '#a7f3d0'} />)}
            </svg>
          )}

          {/* Facility / road / point markers */}
          {emergency.markers.map((marker) => {
            const active = marker.kind === 'hospital' ? layers.hospitals : marker.kind === 'camp' ? layers.camps : marker.kind === 'fire' ? layers.fire : marker.kind === 'blocked' ? layers.roads : layers.points
            if (!active) return null
            const Icon = markerIcon[marker.kind]
            return (
              <div key={marker.id} className="group absolute z-20 -translate-x-1/2 -translate-y-1/2" style={{ left: `${marker.x}%`, top: `${marker.y}%` }}>
                <span className={cn('grid h-5 w-5 place-items-center rounded-md border border-background/70 shadow', markerColor[marker.kind])}>
                  <Icon className="h-3 w-3 text-white" />
                </span>
                <span className="pointer-events-none absolute left-6 top-0 hidden w-max rounded-lg border border-border bg-card px-2 py-1 text-[10px] font-medium shadow-md group-hover:block">{marker.label}{marker.sub ? ` · ${marker.sub}` : ''}</span>
              </div>
            )
          })}

          {/* Location markers (original behavior preserved) */}
          {locations.map((location) => {
            const locationLevel = getRiskLevel(location.risk)
            const locationTone = riskTone(locationLevel)
            const isActive = selected.name === location.name
            return (
              <button key={location.name} onClick={() => onSelect(location.name)} className="group absolute z-30" style={{ left: location.coords.x, top: location.coords.y }} aria-label={`Select ${location.name}`}>
                <span className={cn('block h-3.5 w-3.5 rounded-full border-2 border-background', locationTone.bg, isActive ? 'scale-150 shadow-[0_0_0_7px_rgba(45,212,191,.16)]' : 'group-hover:scale-125', 'transition')} />
                <span className="pointer-events-none absolute left-4 top-1/2 hidden -translate-y-1/2 whitespace-nowrap rounded-lg border border-border bg-card px-2 py-1 text-[10px] font-medium shadow-md group-hover:block">{location.name} · {locationLevel}</span>
              </button>
            )
          })}
        </div>

        <p className="absolute left-5 top-5 z-10 text-[10px] font-bold uppercase tracking-[0.18em] text-slate-300">North Eastern Region · demo map</p>

        <div className="absolute right-4 top-4 z-30 overflow-hidden rounded-xl border border-border bg-card/95 shadow-md">
          <button aria-label="Zoom in" onClick={() => setMapZoom((zoom) => Math.min(1.45, zoom + 0.12))} className="grid h-8 w-8 place-items-center border-b border-border text-muted-foreground transition hover:bg-secondary hover:text-foreground"><ZoomIn className="h-4 w-4" /></button>
          <button aria-label="Zoom out" onClick={() => setMapZoom((zoom) => Math.max(1, zoom - 0.12))} className="grid h-8 w-8 place-items-center border-b border-border text-muted-foreground transition hover:bg-secondary hover:text-foreground"><ZoomOut className="h-4 w-4" /></button>
          <button aria-label="Reset map view" onClick={() => setMapZoom(1)} className="grid h-8 w-8 place-items-center text-muted-foreground transition hover:bg-secondary hover:text-primary"><Crosshair className="h-4 w-4" /></button>
        </div>

        <div className="absolute bottom-4 left-4 z-30 flex max-w-[70%] flex-wrap items-center gap-x-3 gap-y-1 rounded-xl border border-border bg-card/90 px-3 py-2 text-[10px] text-muted-foreground backdrop-blur">
          <span className="flex items-center gap-1"><i className="h-2 w-2 rounded-full bg-emerald-400" />Low</span>
          <span className="flex items-center gap-1"><i className="h-2 w-2 rounded-full bg-yellow-300" />Moderate</span>
          <span className="flex items-center gap-1"><i className="h-2 w-2 rounded-full bg-orange-400" />High</span>
          <span className="flex items-center gap-1"><i className="h-2 w-2 rounded-full bg-red-400" />Extreme</span>
          <span className="flex items-center gap-1"><Route className="h-3 w-3 text-emerald-400" />Evac route</span>
        </div>

        <div className="absolute bottom-4 right-4 z-30 rounded-xl border border-border bg-card/95 p-3 shadow-md backdrop-blur">
          <div className="flex items-start gap-2">
            <Mountain className={cn('mt-0.5 h-4 w-4', tone.text)} />
            <div>
              <p className="text-xs font-semibold">{selected.name}, {selected.state}</p>
              <p className={cn('mt-1 text-[10px] font-bold uppercase tracking-wider', tone.text)}>{level} · {selected.risk}% probability</p>
              <p className="mt-1 text-[10px] text-muted-foreground">{selected.rainfall} mm rain · {selected.slope}° slope</p>
            </div>
          </div>
        </div>
      </div>
      <p className="mt-3 text-[10px] text-muted-foreground">Risk zones, facilities, blocked roads and the evacuation path are simulated demo layers for this prototype.</p>
    </section>
  )
}
