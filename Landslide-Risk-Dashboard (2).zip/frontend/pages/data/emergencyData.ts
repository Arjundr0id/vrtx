// DEMO / SIMULATED DATA MODULE
// Every value produced here is a clearly-labelled prototype estimate.
// No live hospital, weather, road or rescue API is connected in this build.

export type RiskLevel = 'LOW' | 'MODERATE' | 'HIGH' | 'EXTREME'

export type LocationInput = {
  name: string
  state: string
  risk: number
  rainfall: number
  moisture: number
  slope: number
  coords: { x: string; y: string }
}

export type Facility = {
  name: string
  type: 'camp' | 'hospital' | 'fire' | 'team'
  distanceKm: number
  travelMin: number
  status: string
  capacity?: string
  note?: string
}

export type RoadStatus = {
  name: string
  status: 'Open' | 'Partially Blocked' | 'Blocked / Unsafe'
  reason: string
  alternative: string
}

export type RiskZone = {
  id: string
  level: RiskLevel | 'SAFE'
  x: number // percent of map width
  y: number // percent of map height
  w: number
  h: number
  rotate: number
  label: string
}

export type MapMarker = {
  id: string
  kind: 'hospital' | 'camp' | 'fire' | 'blocked' | 'point'
  x: number
  y: number
  label: string
  sub?: string
}

export type PopulationBreakdown = {
  immediate: number
  prepare: number
  low: number
  total: number
  areaKm2: number
}

export type PriorityArea = {
  name: string
  risk: number
  population: number
  roadAccess: 'Good' | 'Limited' | 'Poor'
  distanceToSafeKm: number
  distanceToReliefKm: number
  priority: number
}

export type EmergencyData = {
  isDemo: true
  affectedAreaKm2: number
  population: PopulationBreakdown
  hospitals: Facility[]
  camps: Facility[]
  fire: Facility[]
  teams: Facility[]
  contacts: { name: string; number: string; note: string }[]
  roads: RoadStatus[]
  zones: RiskZone[]
  markers: MapMarker[]
  safeZone: { name: string; x: number; y: number }
  rainfallForecast: { hour: string; rain: number }[]
  currentRainfallMm: number
  expectedRainfallMm: number
  temperatureC: number
  priorityAreas: PriorityArea[]
}

// ---------- deterministic pseudo-random helpers (stable per location) ----------
function seedFrom(text: string): number {
  let hash = 2166136261
  for (let i = 0; i < text.length; i += 1) {
    hash ^= text.charCodeAt(i)
    hash = Math.imul(hash, 16777619)
  }
  return hash >>> 0
}

function rng(seedText: string): () => number {
  let state = seedFrom(seedText)
  return () => {
    state = (state + 0x6d2b79f5) | 0
    let t = Math.imul(state ^ (state >>> 15), 1 | state)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

const pick = (rand: () => number, list: string[], index: number) => list[(index + Math.floor(rand() * list.length)) % list.length] ?? list[0] ?? ''
const between = (rand: () => number, min: number, max: number) => Math.round(min + rand() * (max - min))

export function getRiskLevel(risk: number): RiskLevel {
  if (risk >= 86) return 'EXTREME'
  if (risk >= 65) return 'HIGH'
  if (risk >= 40) return 'MODERATE'
  return 'LOW'
}

export function riskTone(level: RiskLevel) {
  return {
    LOW: { text: 'text-emerald-400', bg: 'bg-emerald-400', soft: 'bg-emerald-400/10 border-emerald-400/25', label: 'Low exposure' },
    MODERATE: { text: 'text-yellow-300', bg: 'bg-yellow-300', soft: 'bg-yellow-300/10 border-yellow-300/25', label: 'Elevated monitoring' },
    HIGH: { text: 'text-orange-400', bg: 'bg-orange-400', soft: 'bg-orange-400/10 border-orange-400/25', label: 'Early warning active' },
    EXTREME: { text: 'text-red-400', bg: 'bg-red-400', soft: 'bg-red-400/10 border-red-400/25', label: 'Critical attention' },
  }[level]
}

const EMERGENCY_CONTACTS = [
  { name: 'National Disaster Helpline (NDMA)', number: '1078', note: 'Disaster response coordination' },
  { name: 'Ambulance / Medical Emergency', number: '108', note: 'Free emergency ambulance service' },
  { name: 'Police Control Room', number: '100', note: 'Law & order, evacuation support' },
  { name: 'Fire & Rescue', number: '101', note: 'Fire, rescue and clearance ops' },
  { name: 'District Emergency Ops Centre', number: '1070', note: 'Local district administration' },
]

const ROAD_REASONS: Record<RoadStatus['status'], string[]> = {
  Open: ['Clear surface, normal traffic flow', 'Patrolled and currently passable', 'No reported debris or waterlogging'],
  'Partially Blocked': ['Falling debris reducing lane width', 'Waterlogging on the lower stretch', 'Ongoing clearance work after minor slide'],
  'Blocked / Unsafe': ['Landslide debris across the carriageway', 'Cracked hillside — closed by district administration', 'Bridge approach washed out by runoff'],
}

// ---------- main generator ----------
export function emergencyDataFor(location: LocationInput): EmergencyData {
  const rand = rng(`${location.name}-${location.state}`)
  const level = getRiskLevel(location.risk)
  const highRisk = level === 'HIGH' || level === 'EXTREME'

  // Population estimates scale with risk and slope
  const basePopulation = between(rand, 3200, 9400)
  const immediate = Math.round(basePopulation * (level === 'EXTREME' ? 0.55 : level === 'HIGH' ? 0.34 : level === 'MODERATE' ? 0.15 : 0.04))
  const prepare = Math.round(basePopulation * (level === 'EXTREME' ? 0.28 : level === 'HIGH' ? 0.3 : level === 'MODERATE' ? 0.28 : 0.16))
  const low = Math.max(0, basePopulation - immediate - prepare)
  const population: PopulationBreakdown = {
    immediate,
    prepare,
    low,
    total: basePopulation,
    areaKm2: Math.round((8 + location.risk * 0.42 + rand() * 6) * 10) / 10,
  }

  const hospitals: Facility[] = [
    { name: `${location.name} Civil Hospital`, type: 'hospital', distanceKm: between(rand, 2, 7), travelMin: 0, status: highRisk ? 'Emergency wing on standby' : 'Open · routine ops', capacity: `${between(rand, 18, 60)} beds available (demo)` },
    { name: `${location.state} Medical College & Hospital`, type: 'hospital', distanceKm: between(rand, 8, 22), travelMin: 0, status: 'Casualty open · trauma unit ready', capacity: `${between(rand, 40, 120)} beds available (demo)` },
    { name: `Regional Trauma Centre — ${pick(rand, ['North', 'South', 'Central'], 0)} wing`, type: 'hospital', distanceKm: between(rand, 12, 30), travelMin: 0, status: highRisk ? 'Prepared for mass-casualty intake' : 'Normal operations', capacity: `${between(rand, 10, 45)} trauma beds (demo)` },
  ]
  const camps: Facility[] = [
    { name: `${location.name} District Relief Camp A`, type: 'camp', distanceKm: between(rand, 3, 9), travelMin: 0, status: 'Ready to activate', capacity: `${between(rand, 300, 900)} persons (demo)` },
    { name: `${pick(rand, ['Government', 'Community', 'Zonal'], 1)} School Shelter — ${location.name} outskirts`, type: 'camp', distanceKm: between(rand, 5, 14), travelMin: 0, status: 'Partially prepared', capacity: `${between(rand, 150, 500)} persons (demo)` },
    { name: `Safe-zone Assembly Point · ${location.name} Ridge Road`, type: 'camp', distanceKm: between(rand, 1, 4), travelMin: 0, status: 'Open assembly point', capacity: 'Open ground · no beds (demo)' },
  ]
  const fire: Facility[] = [
    { name: `${location.name} Fire & Emergency Station`, type: 'fire', distanceKm: between(rand, 2, 6), travelMin: 0, status: highRisk ? 'Crews on alert' : 'On duty', capacity: `${between(rand, 2, 5)} engines ready (demo)` },
    { name: `SDRF Post — ${location.state}`, type: 'fire', distanceKm: between(rand, 10, 26), travelMin: 0, status: 'Search & rescue unit ready', capacity: `${between(rand, 12, 40)} personnel (demo)` },
  ]
  const teams: Facility[] = [
    { name: 'NER Rapid Action Rescue Team (demo)', type: 'team', distanceKm: between(rand, 14, 34), travelMin: 0, status: highRisk ? 'Mobilising (simulated)' : 'Standby', capacity: `${between(rand, 8, 24)} responders` },
    { name: 'Helicopter Response Wing · Umroi / NER base (demo)', type: 'team', distanceKm: between(rand, 25, 60), travelMin: 0, status: highRisk ? 'On 15-min standby' : 'On-call', capacity: 'Airlift + aerial survey' },
    { name: 'NDRF Battalion detachment (demo)', type: 'team', distanceKm: between(rand, 30, 70), travelMin: 0, status: 'Request channel open', capacity: `${between(rand, 40, 90)} personnel` },
  ]
  const allFacilities = [...hospitals, ...camps, ...fire, ...teams]
  allFacilities.forEach((facility) => { facility.travelMin = Math.max(4, Math.round(facility.distanceKm * (1.4 + rand() * 0.9))) })

  const roadNames = [
    `${location.name}–Shillong Highway (NH-${between(rand, 2, 60)})`,
    `${location.name} Bypass Road`,
    `${location.state} State Highway ${between(rand, 1, 18)}`,
    `Hill Cart Road · ${location.name} sector`,
    `Old ${location.name} Trail Road`,
  ]
  const roads: RoadStatus[] = roadNames.slice(0, 5).map((name, index) => {
    const roll = rand() + (highRisk ? 0.25 : 0)
    const status: RoadStatus['status'] = roll > 0.92 ? 'Blocked / Unsafe' : roll > 0.62 ? 'Partially Blocked' : 'Open'
    const reasons = ROAD_REASONS[status]
    return {
      name,
      status,
      reason: reasons[index % reasons.length] ?? reasons[0] ?? 'Demo status',
      alternative: status === 'Open' ? 'Not required' : `Use ${roadNames[(index + 1) % roadNames.length] ?? 'the state highway'}`,
    }
  })

  // Risk zones for the map (deterministic placement around the location point)
  const baseX = parseFloat(location.coords.x)
  const baseY = parseFloat(location.coords.y)
  const zonePlan: { level: RiskLevel | 'SAFE'; count: number }[] = [
    { level: 'EXTREME', count: level === 'EXTREME' ? 2 : level === 'HIGH' ? 1 : 0 },
    { level: 'HIGH', count: level === 'LOW' ? 0 : level === 'MODERATE' ? 1 : 2 },
    { level: 'MODERATE', count: 2 },
    { level: 'SAFE', count: 2 },
  ]
  const zones: RiskZone[] = []
  zonePlan.forEach((group) => {
    for (let i = 0; i < group.count; i += 1) {
      const angle = rand() * Math.PI * 2
      const radius = group.level === 'EXTREME' ? 4 : group.level === 'HIGH' ? 9 : group.level === 'SAFE' ? 22 : 14
      zones.push({
        id: `${group.level}-${i}`,
        level: group.level,
        x: Math.min(88, Math.max(8, baseX + Math.cos(angle) * radius)),
        y: Math.min(84, Math.max(8, baseY + Math.sin(angle) * radius * 0.7)),
        w: between(rand, 90, 190),
        h: between(rand, 60, 110),
        rotate: between(rand, -30, 30),
        label: group.level === 'SAFE' ? 'Low-risk / safe terrain' : `${group.level.toLowerCase()} risk zone (demo)`,
      })
    }
  })
  if (zones.length === 0) zones.push({ id: 'SAFE-0', level: 'SAFE', x: baseX, y: baseY, w: 140, h: 80, rotate: 10, label: 'Low-risk / safe terrain (demo)' })

  const safeZone = zones.find((zone) => zone.level === 'SAFE') ?? { id: 'SAFE-fallback', level: 'SAFE' as const, x: Math.min(85, baseX + 18), y: Math.max(12, baseY - 14), w: 140, h: 80, rotate: 8, label: `${location.name} Ridge safe zone (demo)` }

  const markers: MapMarker[] = [
    ...hospitals.map((hospital, index) => ({ id: `h${index}`, kind: 'hospital' as const, x: Math.min(90, Math.max(6, baseX + (rand() - 0.2) * 30)), y: Math.min(90, Math.max(6, baseY + (rand() - 0.5) * 26)), label: hospital.name, sub: `${hospital.distanceKm} km · demo` })),
    ...camps.slice(0, 2).map((camp, index) => ({ id: `c${index}`, kind: 'camp' as const, x: Math.min(90, Math.max(6, baseX + (rand() - 0.5) * 34)), y: Math.min(90, Math.max(6, baseY + (rand() - 0.4) * 30)), label: camp.name, sub: `${camp.distanceKm} km · demo` })),
    ...fire.map((station, index) => ({ id: `f${index}`, kind: 'fire' as const, x: Math.min(90, Math.max(6, baseX + (rand() - 0.6) * 28)), y: Math.min(90, Math.max(6, baseY + (rand() - 0.5) * 28)), label: station.name, sub: `${station.distanceKm} km · demo` })),
    ...roads.filter((road) => road.status !== 'Open').slice(0, 3).map((road, index) => ({ id: `r${index}`, kind: 'blocked' as const, x: Math.min(90, Math.max(6, baseX + (rand() - 0.5) * 40)), y: Math.min(90, Math.max(6, baseY + (rand() - 0.5) * 34)), label: road.name, sub: road.status })),
    { id: 'home', kind: 'point', x: baseX, y: baseY, label: `${location.name} monitoring point`, sub: 'Selected location' },
    { id: 'safe', kind: 'point', x: safeZone.x, y: safeZone.y, label: safeZone.level === 'SAFE' ? `${location.name} Ridge safe zone (demo)` : 'Safe zone (demo)', sub: 'Designated safe zone' },
  ]

  // 24h rainfall forecast (demo): curve peaking in the next ~6 hours
  const rainfallForecast = Array.from({ length: 12 }, (_, index) => {
    const hour = (new Date().getHours() + index * 2) % 24
    const shape = Math.sin((index / 11) * Math.PI)
    const rain = Math.round((location.rainfall / 12) * (0.35 + shape * (0.7 + rand() * 0.5)))
    return { hour: `${String(hour).padStart(2, '0')}:00`, rain: Math.max(0, rain) }
  })

  const priorityAreas: PriorityArea[] = [
    { name: `${location.name} hillside settlement (demo)`, risk: location.risk, population: Math.round(immediate * 0.52), roadAccess: 'Poor', distanceToSafeKm: between(rand, 1, 3), distanceToReliefKm: between(rand, 3, 8), priority: 0 },
    { name: `${pick(rand, ['Upper', 'Lower', 'Old'], 0)} ${location.name} market area (demo)`, risk: Math.max(20, location.risk - between(rand, 8, 18)), population: Math.round(immediate * 0.31), roadAccess: 'Limited', distanceToSafeKm: between(rand, 2, 5), distanceToReliefKm: between(rand, 4, 10), priority: 0 },
    { name: `${location.name} valley outskirts (demo)`, risk: Math.max(15, location.risk - between(rand, 20, 34)), population: Math.round(prepare * 0.6), roadAccess: 'Good', distanceToSafeKm: between(rand, 4, 9), distanceToReliefKm: between(rand, 6, 14), priority: 0 },
    { name: `Riverside colony · ${location.name} (demo)`, risk: Math.max(10, location.risk - between(rand, 30, 45)), population: Math.round(low * 0.5), roadAccess: 'Good', distanceToSafeKm: between(rand, 6, 12), distanceToReliefKm: between(rand, 8, 18), priority: 0 },
  ]
  priorityAreas.forEach((area) => {
    // Higher risk, larger population, worse road access and longer distances => higher priority (0-100)
    const accessPenalty = area.roadAccess === 'Poor' ? 12 : area.roadAccess === 'Limited' ? 6 : 0
    area.priority = Math.min(99, Math.round(area.risk * 0.55 + Math.min(20, area.population / 90) + accessPenalty + (area.distanceToSafeKm + area.distanceToReliefKm) * 0.7))
  })
  priorityAreas.sort((a, b) => b.priority - a.priority)

  return {
    isDemo: true,
    affectedAreaKm2: population.areaKm2,
    population,
    hospitals,
    camps,
    fire,
    teams,
    contacts: EMERGENCY_CONTACTS,
    roads,
    zones,
    markers,
    safeZone: { name: `Safe zone · ${location.name} Ridge (demo)`, x: safeZone.x, y: safeZone.y },
    rainfallForecast,
    currentRainfallMm: location.rainfall,
    expectedRainfallMm: rainfallForecast.reduce((sum, point) => sum + point.rain, 0),
    temperatureC: between(rand, 14, 31),
    priorityAreas,
  }
}

// ---------- AI evacuation route (demo path planner) ----------
export type EvacuationRoute = {
  waypoints: { x: number; y: number }[]
  distanceKm: number
  travelMin: number
  avoided: string[]
  destination: string
  originName: string
  notes: string
}

export function buildEvacuationRoute(location: LocationInput, data: EmergencyData): EvacuationRoute {
  const rand = rng(`route-${location.name}`)
  const blocked = data.roads.filter((road) => road.status === 'Blocked / Unsafe')
  const originX = parseFloat(location.coords.x)
  const originY = parseFloat(location.coords.y)
  const targetX = data.safeZone.x
  const targetY = data.safeZone.y
  // Bent waypoint path that visually steers around the extreme/high zones
  const detourX = (originX + targetX) / 2 + (rand() - 0.5) * 18
  const detourY = Math.max(10, Math.min(88, (originY + targetY) / 2 - 10 - rand() * 8))
  const waypoints = [
    { x: originX, y: originY },
    { x: detourX, y: detourY },
    { x: targetX, y: targetY },
  ]
  const distanceKm = Math.round((6 + Math.abs(targetX - originX) * 0.55 + Math.abs(targetY - originY) * 0.35) * 10) / 10
  return {
    waypoints,
    distanceKm,
    travelMin: Math.max(8, Math.round(distanceKm * 2.6)),
    avoided: [...blocked.map((road) => road.name), 'Extreme-risk zone (demo)', 'High-risk zone (demo)'],
    destination: data.camps[0]?.name ?? `${location.name} District Relief Camp (demo)`,
    originName: location.name,
    notes: 'Demo routing: path is generated to steer around modelled extreme/high-risk zones and blocked roads. Not a surveyed route.',
  }
}
